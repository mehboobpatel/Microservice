--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2 (Debian 17.2-1.pgdg120+1)
-- Dumped by pg_dump version 17.2 (Debian 17.2-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: new; Type: SCHEMA; Schema: -; Owner: admin
--

CREATE SCHEMA new;


ALTER SCHEMA new OWNER TO admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: migrations; Type: TABLE; Schema: new; Owner: admin
--

CREATE TABLE new.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE new.migrations OWNER TO admin;

--
-- Name: user; Type: TABLE; Schema: new; Owner: admin
--

CREATE TABLE new."user" (
    id integer NOT NULL,
    name character varying NOT NULL,
    email character varying NOT NULL,
    password character varying NOT NULL,
    verified boolean DEFAULT false NOT NULL,
    "verificationToken" character varying
);


ALTER TABLE new."user" OWNER TO admin;

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: new; Owner: admin
--

CREATE SEQUENCE new.user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE new.user_id_seq OWNER TO admin;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: new; Owner: admin
--

ALTER SEQUENCE new.user_id_seq OWNED BY new."user".id;


--
-- Name: user id; Type: DEFAULT; Schema: new; Owner: admin
--

ALTER TABLE ONLY new."user" ALTER COLUMN id SET DEFAULT nextval('new.user_id_seq'::regclass);


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: new; Owner: admin
--

COPY new.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	7b60838825d074698b536a9b5d94122c95449773	2025-02-07 10:08:18.883921
1	insertdummy	055cd2b35531c09fee17dbb6b4cba5ba4276807a	2025-02-07 10:11:15.02191
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: new; Owner: admin
--

COPY new."user" (id, name, email, password, verified, "verificationToken") FROM stdin;
3	Maheboob	trentboult446@gmail.com	$2a$10$uxN6WcfGW1IY4Rjwa.1e5uacwm6vUy/GZqh753ymHJ2pS9kYjCBPC	t	\N
4	Test1	masterpatel786@yahoo.in	$2a$10$Pee9Oi/rxvDiuEPZkQ9Y5.d5ttddgUDa/Mo5iQuK2fydGTc2u8Xhi	t	\N
8	Kon Joe	john.doe@example.com	$2a$10$uxN6WcfGW1IY4Rjwa.1e5uacwm6vUy/GZqh753ymHJ2pS9kYjCBPC	t	
\.


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: new; Owner: admin
--

SELECT pg_catalog.setval('new.user_id_seq', 8, true);


--
-- Name: user PK_cace4a159ff9f2512dd42373760; Type: CONSTRAINT; Schema: new; Owner: admin
--

ALTER TABLE ONLY new."user"
    ADD CONSTRAINT "PK_cace4a159ff9f2512dd42373760" PRIMARY KEY (id);


--
-- Name: user UQ_e12875dfb3b1d92d7d7c5377e22; Type: CONSTRAINT; Schema: new; Owner: admin
--

ALTER TABLE ONLY new."user"
    ADD CONSTRAINT "UQ_e12875dfb3b1d92d7d7c5377e22" UNIQUE (email);


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: new; Owner: admin
--

ALTER TABLE ONLY new.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: new; Owner: admin
--

ALTER TABLE ONLY new.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

